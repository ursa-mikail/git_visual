module github.com/gitvisual/backend

go 1.22

require github.com/lib/pq v1.10.9
